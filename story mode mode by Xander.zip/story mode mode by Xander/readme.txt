install



1. geh in den gta ordner und schiebe die drei datein (dinput8.dll, NativeTrainer.asi, ScriptHookV.dll) in denn gta ordner 
2. starte gta und drücke F5
3. Finish 

ps: dass menu funktioniert nur im story mode



